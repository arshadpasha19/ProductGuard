import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import axios from 'axios';

const SkinConcernScreen = ({ route }) => {
  const { probabilities } = route.params;
  const [concerns, setConcerns] = useState({
    dry: probabilities.dry.toString(),
    normal: probabilities.normal.toString(),
    oily: probabilities.oily.toString(),
    acne: '',
    sensitive: '',
    wrinkles: '',
    redness: '',
    dull: '',
    pore: '',
    pigmentation: '',
    blackheads: '',
    darkCircles: ''
  });
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation(); 

  const handleChange = (key, value) => {
    // Validate the input value
    if (parseFloat(value) >= 0 && parseFloat(value) <= 1.0) {
      setConcerns({ ...concerns, [key]: value });
    } else {
      // Display a warning to the user
      alert('Please enter a value between 0 and 1.0');
    }
  };

  const handleSubmit = async () => {
    try {                                    
      setLoading(true);
      const response = await axios.post('http://192.168.172.222:5000/recommend', { concerns });
      

      if (response.data.error) {
        console.log(response.data.error);
        setLoading(false);
        return;
      }

      const products = response.data.products;
      navigation.navigate('RecommendedProducts', { products });
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safearea}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>Skin Concerns</Text>
        <Text style={styles.description}>Rate your skin concerns from 0 to 1:</Text>
        <View style={styles.formContainer}>
          {Object.keys(concerns).map((key, index) => (
            <View key={index}>
              <Text style={styles.label}>{key.charAt(0).toUpperCase() + key.slice(1)}</Text>
              <TextInput
                style={styles.input}
                onChangeText={(text) => handleChange(key, text)}
                value={concerns[key]}
                keyboardType="numeric"
              />
            </View>
          ))}
        </View>
        <TouchableOpacity onPress={handleSubmit} style={styles.button}>
          {loading ? <ActivityIndicator color="#ffffff" size="small" /> : <Text style={styles.buttonText}>Submit</Text>}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safearea: {
    flex: 1,
  },
  container: {
    alignItems: 'center',
    backgroundColor: '#006666',
    paddingVertical: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#ffffff',
  },
  description: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
    color: '#ffffff',
  },
  formContainer: {
    width: '80%',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    color: '#ffffff',
  },
  input: {
    borderWidth: 1,
    borderColor: '#757575',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    color: '#ffffff',
  },
  button: {
    backgroundColor: '#00b3b3',
    padding: 15,
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    color: '#ffffff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default SkinConcernScreen;
