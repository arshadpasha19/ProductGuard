import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, PermissionsAndroid, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import axios from 'axios';
import * as Animatable from 'react-native-animatable';

function HomeScreen() {
  const navigation = useNavigation();
  const [imageUrl, setImageUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    return () => setIsMounted(false);
  }, []);

  const requestCameraPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: 'Camera Permission',
          message: 'This app requires camera permission.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        }
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn(err);
      return false;
    }
  };

  const openCamera = async () => {
    const cameraPermissionGranted = await requestCameraPermission();

    if (cameraPermissionGranted) {
      const result = await launchCamera();
      setImageUrl(result.assets[0]?.uri);
    } else {
      console.log('Camera permission denied');
    }
  };

  const onPickImageFromImageLibrary = async () => {
    const result = await launchImageLibrary();
    setImageUrl(result.assets[0]?.uri);
  };

  const handleSubmit = async () => {
    try {
      setLoading(true); // Set loading state to true when submitting
      if (!imageUrl) {
        console.log('Please select an image first');
        return;
      }

      const formData = new FormData();
      formData.append('image', {
        uri: imageUrl,
        type: 'image/jpeg',
        name: 'user_image.jpg',
      });

      const response = await axios.post('http://192.168.172.222:5000/predict', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data.error) {
        console.log(response.data.error);
      } else {
        navigation.navigate('SkinConcernScreen', { probabilities: response.data.probabilities });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false); // Reset loading state after submission
    }
  };

  return (
    <View style={styles.container}>
      <Animatable.Text animation={isMounted ? 'fadeInUpBig' : undefined} duration={800} style={styles.title}>
        Welcome to Skin Classification and Recommendation
      </Animatable.Text>
      <Animatable.Text animation={isMounted ? 'fadeInUpBig' : undefined} duration={800} style={styles.description}>
        Upload an image of your face to enable the identification of your skin type,
        allowing for tailored product recommendations specifically suited to your unique skin characteristics.
      </Animatable.Text>

      <TouchableOpacity onPress={openCamera} style={styles.button}>
        <Text style={styles.buttonText}>Select Image from Camera</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onPickImageFromImageLibrary} style={styles.button}>
        <Text style={styles.buttonText}>Select Image from Library</Text>
      </TouchableOpacity>

      {imageUrl && (
        <Animatable.Image animation={isMounted ? 'fadeInUpBig' : undefined} duration={800} source={{ uri: imageUrl }} style={styles.image} />
      )}

      <TouchableOpacity onPress={handleSubmit} style={[styles.button, { backgroundColor: '#F9A825' }]}>
        {loading ? (
          <ActivityIndicator size="small" color="#ffffff" />
        ) : (
          <Text style={styles.buttonText}>Submit</Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#263238',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#FFFFFF',
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    marginBottom: 30,
    textAlign: 'center',
    color: '#FFFFFF',
  },
  image: {
    width: 200,
    height: 200,
    marginBottom: 10,
    borderRadius: 10,
  },
  button: {
    backgroundColor: '#455A64',
    padding: 15,
    marginVertical: 10,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default HomeScreen;
