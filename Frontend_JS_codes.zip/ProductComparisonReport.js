import React from 'react';
import { View, Text, Dimensions, ScrollView, SafeAreaView, StyleSheet } from 'react-native';
import { PieChart } from 'react-native-chart-kit';

const screenWidth = Dimensions.get('window').width;

const ProductComparisonReport = ({ route }) => {
  const { dataset1, dataset2 } = route.params;
  if (dataset1.length === 0 || dataset2.length === 0 ) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.warningContainer}>
          <Text style={styles.instructionsText}>Please upload a proper image of ingredients to view the analysis.</Text>
        </View>
      </SafeAreaView>
    );
  }
  // Calculate the counts for each category for dataset1
  let safeCount1 = 0;
  let moderateCount1 = 0;
  let harmfulCount1 = 0;
  // Calculate the counts for each category for dataset1
  let cancerModerateCount1 = 0;
  let cancerHighCount1 = 0;
  let allergiesModerateCount1 = 0;
  let allergiesHighCount1 = 0;
  let developmentalModerateCount1 = 0;
  let developmentalHighCount1 = 0;
  let useRestrictionsModerateCount1 = 0;
  let useRestrictionsHighCount1 = 0;

  dataset1.forEach(item => {
    const productScore = item['Product Score'];
    const cancerConcern = item['Cancer Concern'];
    const allergies = item['Allergies & Immunotoxicity'];
    const developmental = item['Developmental and Reproductive Toxicity'];
    const useRestrictions = item['Use Restrictions'];

    if (productScore >= 0 && productScore <= 2) {
      safeCount1++;
    } else if (productScore >= 3 && productScore <= 6) {
      moderateCount1++;
    } else if (productScore >= 7 && productScore <= 10) {
      harmfulCount1++;
    }

    // Count concerns for dataset1
    if (cancerConcern === 'MODERATE') {
      cancerModerateCount1++;
    } else if (cancerConcern === 'HIGH') {
      cancerHighCount1++;
    }
  
    // Count allergies concerns
    if (allergies === 'MODERATE') {
      allergiesModerateCount1++;
    } else if (allergies === 'HIGH') {
      allergiesHighCount1++;
    }
  
    // Count developmental concerns
    if (developmental === 'MODERATE') {
      developmentalModerateCount1++;
    } else if (developmental === 'HIGH') {
      developmentalHighCount1++;
    }
  
    // Count use restrictions concerns
    if (useRestrictions === 'MODERATE') {
      useRestrictionsModerateCount1++;
    } else if (useRestrictions === 'HIGH') {
      useRestrictionsHighCount1++;
    }

  });

    
  // Define the data for the pie chart for dataset1
  const pieChartData1 = [
    { name: 'Safe', population: safeCount1, color: '#009d4e' },
    { name: 'Moderate', population: moderateCount1, color: '#ff9e16' },
    { name: 'Harmful', population: harmfulCount1, color: '#e63c2f' }
  ];

  // Calculate the counts for each category for dataset2
  let safeCount2 = 0;
  let moderateCount2 = 0;
  let harmfulCount2 = 0;
  // Calculate the counts for each category for dataset1
  let cancerModerateCount2 = 0;
  let cancerHighCount2 = 0;
  let allergiesModerateCount2 = 0;
  let allergiesHighCount2 = 0;
  let developmentalModerateCount2 = 0;
  let developmentalHighCount2 = 0;
  let useRestrictionsModerateCount2 = 0;
  let useRestrictionsHighCount2 = 0;

  dataset2.forEach(item => {
    const productScore = item['Product Score'];
    const cancerConcern = item['Cancer Concern'];
    const allergies = item['Allergies & Immunotoxicity'];
    const developmental = item['Developmental and Reproductive Toxicity'];
    const useRestrictions = item['Use Restrictions'];

    if (productScore >= 0 && productScore <= 2) {
      safeCount2++;
    } else if (productScore >= 3 && productScore <= 6) {
      moderateCount2++;
    } else if (productScore >= 7 && productScore <= 10) {
      harmfulCount2++;
    }

    // Count concerns for dataset1
    if (cancerConcern === 'MODERATE') {
      cancerModerateCount2++;
    } else if (cancerConcern === 'HIGH') {
      cancerHighCount2++;
    }
  
    // Count allergies concerns
    if (allergies === 'MODERATE') {
      allergiesModerateCount2++;
    } else if (allergies === 'HIGH') {
      allergiesHighCount2++;
    }
  
    // Count developmental concerns
    if (developmental === 'MODERATE') {
      developmentalModerateCount2++;
    } else if (developmental === 'HIGH') {
      developmentalHighCount2++;
    }
  
    // Count use restrictions concerns
    if (useRestrictions === 'MODERATE') {
      useRestrictionsModerateCount2++;
    } else if (useRestrictions === 'HIGH') {
      useRestrictionsHighCount2++;
    }
  });

  // Define the data for the pie chart for dataset2
  const pieChartData2 = [
    { name: 'Safe', population: safeCount2, color: '#009d4e' },
    { name: 'Moderate', population: moderateCount2, color: '#ff9e16' },
    { name: 'Harmful', population: harmfulCount2, color: '#e63c2f' }
  ];

  const calculateNormalizedSafetyScore = (product) => {
    let totalScore = 0;
    const numIngredients = product.length;

    product.forEach(ingredient => {
      let score = 0;
      const productScore = ingredient['Product Score'];
      
      score += productScore;
      score += getScore(ingredient['Allergies & Immunotoxicity']);
      score += getScore(ingredient['Cancer Concern']);
      score += getScore(ingredient['Developmental and Reproductive Toxicity']);
      score += getScore(ingredient['Use Restrictions']);

      totalScore += score;
    });

    const normalizedScore = totalScore / numIngredients;
    return normalizedScore;
  };

  const getScore = (concern) => {
    if (concern === 'MODERATE') {
      return 1;
    } else if (concern === 'HIGH') {
      return 2;
    } else {
      return 0;
    }
  };

  const product1NormalizedScore = calculateNormalizedSafetyScore(dataset1);
  const product2NormalizedScore = calculateNormalizedSafetyScore(dataset2);

  // Determine which product is safer
  let saferProductText;
  if (product1NormalizedScore < product2NormalizedScore) {
    saferProductText = 'Product 1 is better in terms of safety.';
  } else if (product1NormalizedScore > product2NormalizedScore) {
    saferProductText = 'Product 2 is better in terms of safety.';
  } else {
    saferProductText = 'Both products have the same safety score.';
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#B2BABB' }}>
      <ScrollView contentContainerStyle={{ paddingVertical: 20 }}>
        <View style={{ marginBottom: 20 }}>
          <Text style={{ textAlign: 'center', fontSize: 20, marginVertical: 10, color: 'black' }}>product 1 Analysis Report</Text>
          <PieChart
            data={pieChartData1}
            width={screenWidth}
            height={250}
            chartConfig={{
              backgroundColor: '#1cc910',
              backgroundGradientFrom: '#eff3ff',
              backgroundGradientTo: '#efefef',
              decimalPlaces: 2,
              color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        </View>

        <View>
          <Text style={{ textAlign: 'center', fontSize: 20, marginVertical: 10, color: 'black' }}>Product 2 Analysis Report</Text>
          <PieChart
            data={pieChartData2}
            width={screenWidth}
            height={250}
            chartConfig={{
              backgroundColor: '#1cc910',
              backgroundGradientFrom: '#eff3ff',
              backgroundGradientTo: '#efefef',
              decimalPlaces: 2,
              color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        </View>

        <View style={{ marginHorizontal: 20, marginTop: 20, borderWidth: 1, borderColor: 'black',padding: 10, backgroundColor:'lightblue' }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10, color: 'black' }}>Concerns Count for Product 1:</Text>
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Cancer Concern:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{cancerModerateCount1}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{cancerHighCount1}</Text>
            </View>
          </View>

          {/* Allergies Concern */}
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Allergies & Immunotoxicity:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{allergiesModerateCount1}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{allergiesHighCount1}</Text>
            </View>
          </View>

          {/* Developmental Concern */}
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Developmental and Reproductive Toxicity:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{developmentalModerateCount1}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{developmentalHighCount1}</Text>
            </View>
          </View>

          {/* Use Restrictions Concern */}
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Use Restrictions:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{useRestrictionsModerateCount1}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{useRestrictionsHighCount1}</Text>
            </View>
          </View>
        </View>


        <View style={{ marginHorizontal: 20, marginTop: 20, borderWidth: 1, borderColor: 'black',padding: 10, backgroundColor:'lightblue' }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10, color: 'black' }}>Concerns Count for Product 2:</Text>
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Cancer Concern:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{cancerModerateCount2}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{cancerHighCount2}</Text>
            </View>
          </View>

          {/* Allergies Concern */}
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Allergies & Immunotoxicity:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{allergiesModerateCount2}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{allergiesHighCount2}</Text>
            </View>
          </View>

          {/* Developmental Concern */}
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Developmental and Reproductive Toxicity:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{developmentalModerateCount2}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{developmentalHighCount2}</Text>
            </View>
          </View>

          {/* Use Restrictions Concern */}
          <View style={{ marginBottom: 5 }}>
            <Text style={{ fontWeight: 'bold', color: 'black' }}>Use Restrictions:</Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>Moderate:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{useRestrictionsModerateCount2}</Text>
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ flex: 1, color: 'black' }}>High:</Text>
              <Text style={{ fontWeight: 'bold', color: 'black' }}>{useRestrictionsHighCount2}</Text>
            </View>
          </View>
        </View>

        <View style={{ marginHorizontal: 20, marginTop: 20, borderWidth: 1, borderColor: 'black', padding: 10, backgroundColor: 'lightblue' }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10, color: 'black' }}>Safety Comparison:</Text>
          <Text style={{ fontSize: 16, marginBottom: 10, color: 'black' }}>{saferProductText}</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
container: {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#263238',
},
warningContainer: {
  backgroundColor: '#F9A825',
  padding: 20,
  borderRadius: 10,
  alignItems: 'center', // Center items horizontally
},
instructionsText: {
  fontSize: 16,
  color: 'white',
  textAlign: 'center',
},
});

export default ProductComparisonReport;
