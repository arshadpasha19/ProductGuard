// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './HomeScreen';
import IngredientsAnalysis from './IngredientsAnalysis';
import IngredientsAnalysisReport from './IngredientsAnalysisReport';
import ProductComparisonScreen from './ProductComparisonScreen';
import ProductComparisonReport from './ProductComparisonReport';
import SkinClassificationScreen from './SkinClassificationScreen';
import SkinConcernScreen from './SkinConcernScreen';
import RecommendedProducts from './RecommendedProducts';
import ChatbotScreen from './ChatbotScreen';

const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="IngredientsAnalysis" component={IngredientsAnalysis} />
        <Stack.Screen name="IngredientsAnalysisReport" component={IngredientsAnalysisReport} />
        <Stack.Screen name="ProductComparisonScreen" component={ProductComparisonScreen} />
        <Stack.Screen name="ProductComparisonReport" component={ProductComparisonReport} />
        <Stack.Screen name="SkinClassificationScreen" component={SkinClassificationScreen} />
        <Stack.Screen name="SkinConcernScreen" component={SkinConcernScreen} />
        <Stack.Screen name="RecommendedProducts" component={RecommendedProducts} />
        <Stack.Screen name="ChatbotScreen" component={ChatbotScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
