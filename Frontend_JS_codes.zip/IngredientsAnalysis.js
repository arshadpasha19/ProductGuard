//IngredientsAnalysis
import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, PermissionsAndroid, ActivityIndicator} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import axios from 'axios';
import * as Animatable from 'react-native-animatable';

function SelectImageScreen() {
  const navigation = useNavigation();
  const [imageUrl, setImageUrl] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    return () => setIsMounted(false);
  }, []);

  const requestCameraPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: 'Camera Permission',
          message: 'This app requires camera permission.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        }
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn(err);
      return false;
    }
  };

  const openCamera = async () => {
    const cameraPermissionGranted = await requestCameraPermission();

    if (cameraPermissionGranted) {
      const result = await launchCamera();
      if (!result.didCancel) {
        setImageUrl(result.assets[0]?.uri);
      }
    } else {
      console.log('Camera permission denied');
    }
  };

  const pickImageFromImageLibrary = async () => {
    const result = await launchImageLibrary();
    if (!result.didCancel) {
      setImageUrl(result.assets[0]?.uri);
    }
  };

  const handleSubmit = async () => {
    try {
      if (!imageUrl) {
        console.log('Please select an image first');
        return;
      }

      setSubmitting(true); // Set submitting state to true
  
      const formData = new FormData();
      formData.append('image', {
        uri: imageUrl,
        type: 'image/jpeg',
        name: 'user_image.jpg',
      });
  
      const response = await axios.post('http://192.168.172.222:5000/ingredient_analysis', formData, {
        headers: {                       
          'Content-Type': 'multipart/form-data',
        },
      });
      
      if (response.data.error) {
        console.log(response.data.error);
      } else {
        const responseData = JSON.parse(response.data);
        navigation.navigate('IngredientsAnalysisReport', { dataset: responseData });
      }
    } catch (error) {
      console.error(error);
    }
    finally {
      setSubmitting(false); // Reset submitting state to false
    }
  };  

  return (
    <View style={styles.container}>
      <Animatable.Text
        animation={isMounted ? 'fadeInUpBig' : undefined}
        duration={800}
        style={styles.title}
      >
        Welcome to Ingredients Analysis
      </Animatable.Text>
      <Animatable.Text
        animation={isMounted ? 'fadeInUpBig' : undefined}
        duration={800}
        style={styles.description}
      >
        Upload an image of the ingredients list from your cosmetics, toiletries, or other products to analyze the components used 
        with a detailed report based on the ingredients detected.
      </Animatable.Text>
      <TouchableOpacity onPress={openCamera} style={styles.button}>
        <Text style={styles.buttonText}>Select Image from Camera</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={pickImageFromImageLibrary} style={styles.button}>
        <Text style={styles.buttonText}>Select Image from Library</Text>
      </TouchableOpacity>
      {imageUrl && (
        <Image source={{ uri: imageUrl }} style={styles.image} />
      )}
      <TouchableOpacity onPress={handleSubmit} style={[styles.button, { backgroundColor: '#F9A825' }]}>
        {submitting ? ( // Show loading indicator if submitting is true
          <ActivityIndicator size="small" color="#FFFFFF" />
        ) : (
          <Text style={styles.buttonText}>Submit</Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#263238',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#FFFFFF',
  },
  description: {
    fontSize: 16,
    marginBottom: 30,
    textAlign: 'center',
    paddingHorizontal: 20,
    color: '#FFFFFF',
  },
  image: {
    width: 200,
    height: 200,
    marginBottom: 20,
    borderRadius: 10,
  },
  button: {
    backgroundColor: '#455A64',
    padding: 15,
    marginVertical: 10,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default SelectImageScreen;
