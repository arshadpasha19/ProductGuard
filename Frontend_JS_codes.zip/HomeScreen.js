import React from 'react';
import { View, Text, Button, StyleSheet, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import * as Animatable from 'react-native-animatable';

function HomeScreen() {
  const navigation = useNavigation();

  const handleIngredientsAnalysis = () => {
    navigation.navigate('IngredientsAnalysis');
  };

  const handleProductComparison = () => {
    navigation.navigate('ProductComparisonScreen');
  };

  const handleSkinClassification = () => {
    navigation.navigate('SkinClassificationScreen');
  };

  const handleChatbot = () => {
    navigation.navigate('ChatbotScreen');
  };

  return (
    <ImageBackground source={require('./bg2.jpg')} style={styles.backgroundImage}>
      <View style={styles.container}>
      <Animatable.View animation="fadeInDownBig" duration={1500}>
        <Text style={{fontSize:26,fontWeight: 'bold',marginBottom: 10, }}>Welcome to ProductGuard</Text>
        </Animatable.View>
        <Animatable.View animation="fadeInUpBig" duration={1500} style={styles.buttonContainer}>
          <Button 
            title="Ingredients Analysis" 
            onPress={handleIngredientsAnalysis} 
            color="#330000" 
          />
        </Animatable.View>
        <Animatable.View animation="fadeInUpBig" duration={1500} delay={200} style={styles.buttonContainer}>
          <Button 
            title="Product Comparison" 
            onPress={handleProductComparison} 
            color="#330000" 
          />
        </Animatable.View>
        <Animatable.View animation="fadeInUpBig" duration={1500} delay={400} style={styles.buttonContainer}>
          <Button 
            title="Skin Classification and Recommendation" 
            onPress={handleSkinClassification} 
            color="#330000" 
          />
        </Animatable.View>
        <Animatable.View animation="fadeInUpBig" duration={1500} delay={600} style={styles.buttonContainer}>
          <Button 
            title="Chatbot" 
            onPress={handleChatbot} 
            color="#330000" 
          />
        </Animatable.View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  buttonContainer: {
    marginVertical: 10,
    width: '80%',
  },
});

export default HomeScreen;
