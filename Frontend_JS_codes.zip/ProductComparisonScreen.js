import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, PermissionsAndroid, ScrollView, SafeAreaView, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';
import axios from 'axios';
import * as Animatable from 'react-native-animatable';

function ProductComparisonScreen() {
  const navigation = useNavigation();
  const [imageUrl1, setImageUrl1] = useState(null);
  const [imageUrl2, setImageUrl2] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    return () => setIsMounted(false);
  }, []);

  const requestCameraPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: 'Camera Permission',
          message: 'This app requires camera permission.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        }
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    } catch (err) {
      console.warn(err);
      return false;
    }
  };

  const openCamera = async (setImage) => {
    const cameraPermissionGranted = await requestCameraPermission();

    if (cameraPermissionGranted) {
      const result = await launchCamera();
      if (!result.didCancel) {
        setImage(result.assets[0]?.uri);
      }
    } else {
      console.log('Camera permission denied');
    }
  };

  const pickImageFromImageLibrary = async (setImage) => {
    const result = await launchImageLibrary();
    if (!result.didCancel) {
      setImage(result.assets[0]?.uri);
    }
  };

  const handleSubmit = async () => {
    try {
      if (!imageUrl1 || !imageUrl2) {
        console.log('Please select both images first');
        return;
      }

      setLoading(true); // Show loading indicator
  
      const formData1 = new FormData();
      formData1.append('image', {
        uri: imageUrl1,
        type: 'image/jpeg',
        name: 'image1.jpg',
      });
      formData1.append('productId', '1');

      const formData2 = new FormData();
      formData2.append('image', {
        uri: imageUrl2,
        type: 'image/jpeg',
        name: 'image2.jpg',
      });
      formData2.append('productId', '2');

      const [response1, response2] = await Promise.all([
        axios.post('http://192.168.172.222:5000/ingredient_analysis', formData1, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }),
        axios.post('http://192.168.172.222:5000/ingredient_analysis', formData2, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        })
      ]);
      
      if (response1.data.error) {
        console.log(response1.data.error);
        setLoading(false); // Hide loading indicator
        return;
      }

      if (response2.data.error) {
        console.log(response2.data.error);
        setLoading(false); // Hide loading indicator
        return;
      }

      setLoading(false); // Hide loading indicator

      const responseData1 = JSON.parse(response1.data);
      const responseData2 = JSON.parse(response2.data);
      navigation.navigate('ProductComparisonReport', { dataset1: responseData1, dataset2: responseData2 });
    } catch (error) {
      console.error(error);
      setLoading(false); // Hide loading indicator
    }
  };  

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <Animatable.Text
          animation={isMounted ? 'fadeInUpBig' : undefined}
          duration={800}
          style={styles.title}
        >
          Welcome to Product Comparison!
        </Animatable.Text>
        <Animatable.Text
          animation={isMounted ? 'fadeInUpBig' : undefined}
          duration={800}
          style={styles.description}
        >
          Upload images of the ingredients lists for two products to determine their safety profiles and 
          know which one is safer than the other based on the analysis of their ingredients.
        </Animatable.Text>
        
        
          <Text>Upload Product 1 Image</Text>
          <TouchableOpacity onPress={() => openCamera(setImageUrl1)} style={styles.button}>
            <Text style={styles.buttonText}>Select Image 1 from Camera</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => pickImageFromImageLibrary(setImageUrl1)} style={styles.button}>
            <Text style={styles.buttonText}>Select Image 1 from Library</Text>
          </TouchableOpacity>
          {imageUrl1 && (
            <Image source={{ uri: imageUrl1 }} style={styles.image} />
          )}

          <Text>Upload Product 2 Image</Text>
          <TouchableOpacity onPress={() => openCamera(setImageUrl2)} style={styles.button}>
            <Text style={styles.buttonText}>Select Image 2 from Camera</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => pickImageFromImageLibrary(setImageUrl2)} style={styles.button}>
            <Text style={styles.buttonText}>Select Image 2 from Library</Text>
          </TouchableOpacity>
          {imageUrl2 && (
            <Image source={{ uri: imageUrl2 }} style={styles.image} />
          )}

          <TouchableOpacity onPress={handleSubmit} style={[styles.button, { backgroundColor: '#F9A825' }]}>
            <Text style={styles.buttonText}>Submit</Text>
          </TouchableOpacity>
          {loading && <ActivityIndicator size="large" color="#ffffff" />}
        
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#263238',
  },
  scrollViewContent: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#FFFFFF',
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    marginBottom: 30,
    textAlign: 'center',
    color: '#FFFFFF',
  },
  image: {
    width: 200,
    height: 200,
    marginBottom: 20,
    borderRadius: 10,
  },
  button: {
    backgroundColor: '#455A64',
    padding: 15,
    marginVertical: 10,
    borderRadius: 10,
    width: '80%',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default ProductComparisonScreen;
