import React from 'react';
import { View, Text, StyleSheet, ScrollView, SafeAreaView } from 'react-native';

function RecommendedProducts({ route }) {
  const { products } = route.params;

  return (
    <SafeAreaView style={styles.safearea}>
      <ScrollView contentContainerStyle={styles.container}>
        {Object.entries(products).map(([category, items]) => (
          <View key={category} style={styles.categoryContainer}>
            <Text style={styles.categoryTitle}>{category}</Text>
            {items.map((item, index) => (
              <View key={index} style={styles.itemContainer}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text style={styles.itemDetails}>Brand: {item.brand}</Text>
                <Text style={styles.itemDetails}>Price: {item.price}</Text>
                <Text style={styles.itemDetails}>Skin Type: {item['skin type']}</Text>
                <Text style={styles.itemDetails}>Concern: {item.concern}</Text>
                <Text style={styles.itemDetails}>URL: {item.url}</Text>
              </View>
            ))}
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safearea: {
    flex: 1,
    backgroundColor: '#1f2833', // Dark blue background color
  },
  container: {
    paddingVertical: 20,
    paddingHorizontal: 15,
  },
  categoryContainer: {
    marginBottom: 20,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#66FCF1', // Turquoise text color
  },
  itemContainer: {
    borderWidth: 1,
    borderColor: '#45A29E', // Turquoise border color
    borderRadius: 8,
    padding: 12,
    marginBottom: 10,
    backgroundColor: '#0B0C10', // Dark gray background color
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#C5C6C7', // Light gray text color
  },
  itemDetails: {
    fontSize: 14,
    color: '#C5C6C7', // Light gray text color
  },
});

export default RecommendedProducts;
