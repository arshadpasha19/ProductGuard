import React, { useEffect } from 'react';
import { View, Text, Dimensions, ScrollView, SafeAreaView, StatusBar, StyleSheet } from 'react-native';
import { PieChart } from 'react-native-chart-kit';
import * as Animatable from 'react-native-animatable';

const screenWidth = Dimensions.get('window').width;

const IngredientsAnalysisReport = ({ route }) => {
  const { dataset } = route.params;
  useEffect(() => {
    StatusBar.setBarStyle('light-content'); // Set status bar style to light
  }, []);

  if (dataset.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.warningContainer}>
          <Text style={styles.instructionsText}>Please upload a proper image of ingredients to view the analysis.</Text>
        </View>
      </SafeAreaView>
    );
  }

  // Calculate the counts for each category
  let safeCount = 0;
  let moderateCount = 0;
  let harmfulCount = 0;

  // Calculate counts for each concern
  let cancerConcernCount = 0;
  let allergiesCount = 0;
  let developmentalCount = 0;
  let useRestrictionsCount = 0;

  dataset.forEach(item => {
    const productScore = item['Product Score'];
    const cancerConcern = item['Cancer Concern'];
    const allergies = item['Allergies & Immunotoxicity'];
    const developmental = item['Developmental and Reproductive Toxicity'];
    const useRestrictions = item['Use Restrictions'];

    // Count safe, moderate, and harmful products
    if (productScore >= 0 && productScore <= 2) {
      safeCount++;
    } else if (productScore >= 3 && productScore <= 6) {
      moderateCount++;
    } else if (productScore >= 7 && productScore <= 10) {
      harmfulCount++;
    }

    // Count products with moderate or high concerns
    if (cancerConcern === 'MODERATE' || cancerConcern === 'HIGH') {
      cancerConcernCount++;
    }
    if (allergies === 'MODERATE' || allergies === 'HIGH') {
      allergiesCount++;
    }
    if (developmental === 'MODERATE' || developmental === 'HIGH') {
      developmentalCount++;
    }
    if (useRestrictions === 'MODERATE' || useRestrictions === 'HIGH') {
      useRestrictionsCount++;
    }
  });
  const getColorCode = (score) => {
    if (score >= 0 && score <= 2) {
      return '#009d4e';
    } else if (score >= 3 && score <= 6) {
      return '#ff9e16';
    } else if (score >= 7 && score <= 10) {
      return '#e63c2f';
    }
  };
  // Define the data for the pie chart
  const pieChartData = [
    { name: 'Safe', population: safeCount, color: '#009d4e' },
    { name: 'Moderate', population: moderateCount, color: '#ff9e16' },
    { name: 'Harmful', population: harmfulCount, color: '#e63c2f' }
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#B2BABB' }}>
      <ScrollView contentContainerStyle={{ paddingVertical: 20, paddingHorizontal: 10 }}>
        <Animatable.Text animation="fadeInDown" style={{ textAlign: 'center', fontSize: 24, marginBottom: 20, color: 'black' }}>Ingredients Analysis Report</Animatable.Text>
        <Animatable.View animation="fadeInUpBig">
          <PieChart
            data={pieChartData}
            width={screenWidth - 20}
            height={250}
            chartConfig={{
              backgroundColor: '#1cc910',
              backgroundGradientFrom: '#eff3ff',
              backgroundGradientTo: '#efefef',
              decimalPlaces: 2,
              color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
          />
        </Animatable.View>
        <Animatable.View animation="fadeInUpBig" style={{ marginVertical: 20 }}>
          <Text style={styles.sectionTitle}>Concerns Count:</Text>
          <View style={styles.concernItem}>
            <Text style={styles.concernText}>Cancer Concern:</Text>
            <Text style={styles.concernCount}>{cancerConcernCount}</Text>
          </View>
          <View style={styles.concernItem}>
            <Text style={styles.concernText}>Allergies & Immunotoxicity:</Text>
            <Text style={styles.concernCount}>{allergiesCount}</Text>
          </View>
          <View style={styles.concernItem}>
            <Text style={styles.concernText}>Developmental and Reproductive Toxicity:</Text>
            <Text style={styles.concernCount}>{developmentalCount}</Text>
          </View>
          <View style={styles.concernItem}>
            <Text style={styles.concernText}>Use Restrictions:</Text>
            <Text style={styles.concernCount}>{useRestrictionsCount}</Text>
          </View>
        </Animatable.View>
        <Animatable.View animation="fadeInUpBig">
          <Text style={styles.sectionTitle}>Ingredients Information:</Text>
          {dataset.map((item, index) => (
            <View key={index} style={[styles.elementItem, { backgroundColor: getColorCode(item['Product Score']) }]}>
              <Text style={styles.elementText}>Ingredient Name: {item['Product Name']}</Text>
              <Text style={styles.elementText}>Ingredient Score: {item['Product Score']}</Text>
              <Text style={styles.elementText}>Cancer Concern: {item['Cancer Concern']}</Text>
              <Text style={styles.elementText}>Allergies & Immunotoxicity: {item['Allergies & Immunotoxicity']}</Text>
              <Text style={styles.elementText}>Developmental and Reproductive Toxicity: {item['Developmental and Reproductive Toxicity']}</Text>
              <Text style={styles.elementText}>Use Restrictions: {item['Use Restrictions']}</Text>
              <Text style={styles.elementText}>Other Concerns: {item['Other Concerns']}</Text>
            </View>
          ))}
        </Animatable.View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'black',
  },
  concernItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  concernText: {
    flex: 1,
    color: 'black',
  },
  concernCount: {
    fontWeight: 'bold',
    color: 'black',
  },
  elementItem: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: 'lightblue',
    borderRadius: 8,
  },
  elementText: {
    marginBottom: 5,
    color: 'black',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#263238',
  },
  warningContainer: {
    backgroundColor: '#F9A825',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center', // Center items horizontally
  },
  instructionsText: {
    fontSize: 16,
    color: 'white',
    textAlign: 'center',
  },
});

export default IngredientsAnalysisReport;
