import React, { useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, SafeAreaView, StyleSheet, ActivityIndicator } from 'react-native';
import axios from 'axios';
import * as Animatable from 'react-native-animatable';

const ChatbotScreen = ({ navigation }) => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const responseContainerRef = useRef(null);

  const handleQuerySubmit = async () => {
    setIsLoading(true); // Set loading state to true when query is submitted

    try {
      const response = await axios.post('http://192.168.172.222:5000/chatbot', { query });
      setResponse(response.data.answer);
      // Apply animation to the response container
      responseContainerRef.current?.bounceIn(800);
    } catch (error) {
      console.error('Error fetching response: ', error);
    } finally {
      setIsLoading(false); // Set loading state to false after response is fetched
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <Animatable.Text animation="fadeInDown" duration={800} style={styles.title}>
          Welcome to SkinCareGenie
        </Animatable.Text>
        <Animatable.Text animation="fadeInDown" duration={800} delay={200} style={styles.subtitle}>
          How can I help you?
        </Animatable.Text>
        <View style={styles.innerContainer}>
          <Animatable.View animation="fadeIn" duration={800} delay={400} style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="Enter your query"
              value={query}
              onChangeText={(text) => setQuery(text)}
            />
            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleQuerySubmit}
            >
              <Text style={styles.submitButtonText}>Submit</Text>
            </TouchableOpacity>
          </Animatable.View>

          {isLoading ? ( // Render loading indicator if isLoading is true
            <ActivityIndicator size="large" color="#61dafb" style={styles.loadingIndicator} />
          ) : (
            response ? (
              <Animatable.View ref={responseContainerRef} animation="fadeInUp" duration={800} delay={600} style={styles.responseContainer}>
                <Text style={styles.response}>{response}</Text>
              </Animatable.View>
            ) : null
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  innerContainer: {
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#61dafb',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: '#61dafb',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputContainer: {
    alignItems: 'center',
  },
  input: {
    width: '80%',
    marginBottom: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    color: '#f4f1de',
    backgroundColor: '#2b2b2b',
  },
  responseContainer: {
    marginTop: 20,
    alignItems: 'center',
  },
  response: {
    fontSize: 16,
    color: '#f4f1de',
    backgroundColor: '#2b2b2b',
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  loadingIndicator: {
    marginTop: 20,
  },
  submitButton: {
    backgroundColor: '#61dafb',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 10,
  },
  submitButtonText: {
    color: '#f4f1de',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default ChatbotScreen;
